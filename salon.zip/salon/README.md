# salon
Step1. npm run build
Step2. npm run server
